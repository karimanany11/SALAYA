# Salaya

Website prototype for Salaya flower studio (Egypt): animated intro, ready bouquets, build-your-own bouquet, WhatsApp ordering, Arabic/English.

Live site: GitHub Pages (Settings → Pages → Deploy from branch `main`, folder `/root`).
